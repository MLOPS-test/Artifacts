import { test } from 'node:test';
import assert from 'node:assert';
import { checkLimits, LIMIT_TYPES } from '../lib/limits.js';

test('checkLimits: clean book under both limits → no breaches', () => {
  const book = {
    bookId: 'TEST-CLEAN',
    nav: 10000000,
    positions: [
      { marketValue: 1200000 },
      { marketValue: -800000 },
    ],
    pnlHistory: [12000, -34000, 8100, -51000, 22300, -18900, 41200, -27600],
  };
  const limits = { 'TEST-CLEAN': { var: 100000, gross_exposure: 5000000 } };
  const breaches = checkLimits(book, limits);
  assert.deepStrictEqual(breaches, []);
  assert.ok(LIMIT_TYPES.includes('var'));
  assert.ok(LIMIT_TYPES.includes('gross_exposure'));
});
