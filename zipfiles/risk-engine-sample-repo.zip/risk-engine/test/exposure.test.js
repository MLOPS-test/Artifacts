import { test } from 'node:test';
import assert from 'node:assert';
import { holdingDays, grossExposure, netExposure } from '../lib/exposure.js';

test('holdingDays: 15-day hold with ~300ms mark latency → 15, not 16', () => {
  // Mark feeds stamp a few hundred ms past the EOD cut.
  // elapsed = 15.0000035 days. Floor, not ceil.
  const opened = '2026-03-01T00:00:00.000Z';
  const asOf   = '2026-03-16T00:00:00.300Z';
  assert.strictEqual(holdingDays(opened, asOf), 15);
});

test('gross and net exposure: shorts add to gross, subtract from net', () => {
  const positions = [
    { marketValue:  4000000 },
    { marketValue: -1500000 },
    { marketValue:  2500000 },
  ];
  assert.strictEqual(grossExposure(positions), 8000000);
  assert.strictEqual(netExposure(positions), 5000000);
});
