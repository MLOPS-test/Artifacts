import { test } from 'node:test';
import assert from 'node:assert';
import { historicalVaR } from '../lib/var.js';

test('historicalVaR: 99% on 100-obs vector picks the worst loss', () => {
  // 98 small obs around zero, plus two tail losses.
  const pnl = Array.from({ length: 98 }, (_, i) => (i % 2 === 0 ? 1000 : -1000));
  pnl.push(-87000, -42000);
  const v = historicalVaR(pnl, 0.99);
  assert.strictEqual(v, 87000);
});
