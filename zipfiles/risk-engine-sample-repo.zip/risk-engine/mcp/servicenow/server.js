#!/usr/bin/env node
// Mock ServiceNow MCP server — incident record + CI owner for the breached book.
// Zero npm deps; speaks stdio JSON-RPC via ../_stdio.js.

import { serve } from '../_stdio.js';

const RECORDS = {
  'INC-4412': {
    record: 'INC-4412',
    sev: 'sev2',
    assigned: 'risk-eng',
    ci: 'BOOK-EQTY-02',
    owner: 'Equity Risk Desk',
    contact: 'j.okonkwo@ms.com',
  },
  'BOOK-EQTY-02': {
    record: 'INC-4412',
    sev: 'sev2',
    assigned: 'risk-eng',
    ci: 'BOOK-EQTY-02',
    owner: 'Equity Risk Desk',
    contact: 'j.okonkwo@ms.com',
  },
};

serve({
  name: 'ms-servicenow',
  tools: [
    {
      name: 'get_record',
      description: 'Fetch a ServiceNow record (incident or CI) by name/ID. Returns sev, assignment group, CI, and owner contact.',
      inputSchema: {
        type: 'object',
        properties: { name: { type: 'string', description: 'Incident ID (INC-4412) or CI name (BOOK-EQTY-02)' } },
        required: ['name'],
      },
      handler: ({ name }) =>
        RECORDS[name] ?? RECORDS['INC-4412'],
    },
  ],
});
