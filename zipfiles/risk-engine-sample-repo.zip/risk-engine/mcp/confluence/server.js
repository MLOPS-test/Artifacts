#!/usr/bin/env node
// Mock Confluence MCP server — search returns the VaR Breach Runbook.
// Zero npm deps; speaks stdio JSON-RPC via ../_stdio.js.

import { serve } from '../_stdio.js';

const RUNBOOK = {
  page_id: 'RISK-RB-07',
  title: 'VaR Breach Runbook',
  body:
    '1. Confirm breach via /stress-test\n' +
    '2. Confirm limit in data/limits.yaml\n' +
    '3. Do NOT edit limits.yaml — open RISK-LIMITS Jira with MD sign-off\n' +
    '4. Notify #risk-ops',
};

serve({
  name: 'ms-confluence',
  tools: [
    {
      name: 'search',
      description: 'Search Confluence for a runbook or policy page',
      inputSchema: {
        type: 'object',
        properties: { query: { type: 'string', description: 'e.g. "VaR breach runbook"' } },
        required: ['query'],
      },
      handler: ({ query }) => ({ query, ...RUNBOOK }),
    },
  ],
});
