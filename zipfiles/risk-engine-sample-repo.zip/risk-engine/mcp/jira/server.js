#!/usr/bin/env node
// Mock Jira MCP server — create_issue + get_issue for RISK-LIMITS-892.
// Zero npm deps; speaks stdio JSON-RPC via ../_stdio.js.

import { serve } from '../_stdio.js';

let seq = 892;
const ISSUES = {
  'RISK-LIMITS-892': {
    key: 'RISK-LIMITS-892',
    url: 'https://jira.ms.com/browse/RISK-LIMITS-892',
    status: 'Open',
    summary: 'BOOK-EQTY-02 VaR breach — $2.3M vs $2.0M limit',
    proposed_limit: 2500000,
    description: 'Historical VaR $2,314,700 exceeds $2,000,000 limit. Owner: Equity Risk Desk (j.okonkwo@ms.com). Ref INC-4412.',
  },
};

serve({
  name: 'ms-jira',
  tools: [
    {
      name: 'create_issue',
      description: 'Create a Jira issue. Returns the new issue key + URL.',
      inputSchema: {
        type: 'object',
        properties: {
          project:        { type: 'string', description: 'e.g. RISK-LIMITS' },
          summary:        { type: 'string' },
          description:    { type: 'string' },
          proposed_limit: { type: 'number', description: 'Proposed new VaR limit (USD)' },
        },
        required: ['project', 'summary'],
      },
      handler: ({ project, summary, description, proposed_limit }) => {
        const key = `${project || 'RISK-LIMITS'}-${seq++}`;
        const issue = {
          key,
          url: `https://jira.ms.com/browse/${key}`,
          status: 'Open',
          summary,
          proposed_limit: proposed_limit ?? null,
          description: description ?? '',
        };
        ISSUES[key] = issue;
        return issue;
      },
    },
    {
      name: 'get_issue',
      description: 'Fetch a Jira issue by key (e.g. RISK-LIMITS-892)',
      inputSchema: {
        type: 'object',
        properties: { key: { type: 'string' } },
        required: ['key'],
      },
      handler: ({ key }) =>
        ISSUES[key] ?? { error: `Issue ${key} not found`, available: Object.keys(ISSUES) },
    },
  ],
});
