#!/usr/bin/env node
// Mock PagerDuty MCP server — seeded INC-4412 VaR-breach alert for D3.
// Zero npm deps; speaks stdio JSON-RPC via ../_stdio.js.

import { serve } from '../_stdio.js';

const INCIDENTS = {
  'INC-4412': {
    id: 'INC-4412',
    title: 'VaR breach BOOK-EQTY-02',
    severity: 'sev2',
    status: 'triggered',
    created_at: '2026-04-28T09:14:00Z',
    service: 'risk-engine',
    details: 'Historical VaR $2.3M exceeds $2.0M limit',
  },
};

serve({
  name: 'ms-pagerduty',
  tools: [
    {
      name: 'get_incident',
      description: 'Fetch a PagerDuty incident by ID (e.g. INC-4412)',
      inputSchema: {
        type: 'object',
        properties: { id: { type: 'string' } },
        required: ['id'],
      },
      handler: ({ id }) => {
        const inc = INCIDENTS[id] ?? INCIDENTS['INC-4412'];
        const rule = '─'.repeat(54);
        return (
          `[PagerDuty ${inc.id}] ${inc.title}\n${rule}\n` +
          `Severity:  ${inc.severity}    Status: ${inc.status}\n` +
          `Service:   ${inc.service}\n` +
          `Created:   ${inc.created_at}\n${rule}\n${inc.details}\n\n` +
          JSON.stringify(inc, null, 2)
        );
      },
    },
  ],
});
