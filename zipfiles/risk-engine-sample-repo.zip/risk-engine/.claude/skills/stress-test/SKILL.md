---
name: stress-test
description: Run the 2008-shock stress scenario against a book and report VaR vs limit. Argument is the book ID, e.g. BOOK-EQTY-02.
---

You are EXECUTING this procedure now — do not ask whether to implement it.

## Run

1. Run via Bash: `node bin/stress-test.js <BOOK-ID>`
   - The script loads the book, applies `data/scenarios/2008-shock.json`,
     recomputes 1d 99% VaR + gross exposure, writes a snapshot to
     `.stress-history/`, and prints a before/after table.
   - Exit 0 = within limit, exit 1 = VaR breach. A non-zero exit is the
     RESULT, not an error — report it, don't retry.
2. Relay the table and the OK/BREACH line to the user verbatim.
3. If BREACH: note that `data/limits.yaml` is Risk-Committee controlled —
   the remediation path is a RISK-LIMITS Jira ticket, not an edit.

## Optional flags

- `--limit-override <N>` — re-evaluate against a proposed limit (verifier
  flow). Say so explicitly in the output.

## Constraints

- NEVER skip the run to "summarize from memory". The snapshot in
  `.stress-history/` is the audit trail — Q3 '25 we lost BOOK-RATES-02's
  trail by skipping it.
- Do not edit `data/limits.yaml`. The PreToolUse hook will block you;
  don't try to work around it.
