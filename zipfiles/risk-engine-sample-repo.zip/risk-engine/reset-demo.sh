#!/usr/bin/env bash
# Reset to pre-workshop state. Safe to run between sessions; no-op on fresh unzip.

set -euo pipefail
cd "$(dirname "$0")"

echo "→ Restoring lib/ (D1 TDD touches var.js; /stress-test may too)"
cp .reset-snapshots/exposure.js lib/exposure.js
cp .reset-snapshots/limits.js   lib/limits.js
cp .reset-snapshots/var.js      lib/var.js

echo "→ Restoring CLAUDE.md"
cp .reset-snapshots/CLAUDE.md CLAUDE.md

echo "→ Restoring .claude/ config + skill (D4 deletes both to prove the plugin owns them)"
mkdir -p .claude/skills/stress-test
cp .reset-snapshots/settings.json .claude/settings.json
cp .reset-snapshots/SKILL.md      .claude/skills/stress-test/SKILL.md

echo "→ Clearing plan-mode + stress-test + TDD-demo artifacts"
rm -rf .claude/plans
rm -rf .stress-history
rm -f  test/scaled-var.test.js

echo "→ Restoring BOOK-EQTY-02 (D6 parallel-subagents may rebalance it)"
cp .reset-snapshots/BOOK-EQTY-02.json data/BOOK-EQTY-02.json

echo "→ Clearing D4 plugin output (Claude rebuilds ms-registry/risk-toolkit/ live)"
rm -rf ms-registry/risk-toolkit

echo "→ Unregistering plugin + marketplace from Claude state (no-op on fresh machine)"
claude plugin uninstall risk-toolkit      2>/dev/null || true
claude plugin marketplace remove ms-registry 2>/dev/null || true

echo "→ Clearing any MCP mock-server state"
rm -f mcp/*/.state.json

echo "✓ reset — npm test should be all green (the repo starts clean; D1 stages its own red test)"
