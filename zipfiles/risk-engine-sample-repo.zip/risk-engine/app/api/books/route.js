import fs from 'node:fs';
import path from 'node:path';

export async function GET() {
  const files = fs.readdirSync('data').filter((f) => /^BOOK-.*\.json$/.test(f));
  const books = files.map((f) => {
    const b = JSON.parse(fs.readFileSync(path.join('data', f), 'utf8'));
    return { bookId: b.bookId, desk: b.desk, nav: b.nav, positions: b.positions.length };
  });
  return Response.json({ books });
}
