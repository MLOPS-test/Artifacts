import fs from 'node:fs';
import path from 'node:path';
import { checkLimits } from '../../../lib/limits.js';
import { bookVaR } from '../../../lib/var.js';
import { grossExposure, netExposure } from '../../../lib/exposure.js';

export async function GET(request) {
  const url = new URL(request.url);
  const bookId = url.searchParams.get('book');
  // Allowlist the book id before it touches the filesystem — otherwise a
  // crafted ?book= value (e.g. ../../etc/passwd) would traverse out of data/.
  if (!bookId || !/^BOOK-[A-Z]+-\d+$/.test(bookId)) {
    return Response.json({ error: 'missing or invalid ?book=' }, { status: 400 });
  }

  const book = JSON.parse(fs.readFileSync(path.join('data', `${bookId}.json`), 'utf8'));

  return Response.json({
    bookId,
    var99: bookVaR(book),
    gross: grossExposure(book.positions),
    net: netExposure(book.positions),
    breaches: checkLimits(book),
  });
}
