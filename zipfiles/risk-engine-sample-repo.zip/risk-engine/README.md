# risk-engine

Position-risk and VaR service for trading books. Computes 1-day 99%
historical VaR, gross/net exposure, and checks each book against the
Risk-Committee limits in `data/limits.yaml`.

This is the demo vehicle for the **Morgan Stanley 301 60 Min** workshop
(session 3 of the 101→201→301 series). Same vehicle as 101 and 201,
extended with three books, a local plugin marketplace, five mock MCP
servers, and three custom agents.

## Layout

```
lib/                ← exposure/limits/var (same as 101/201, all clean)
test/               ← 4 tests, all pass
data/
  BOOK-EQTY-01.json ← Clean book — VaR $1.6M, under limit
  BOOK-EQTY-02.json ← The hot book — VaR ~$2.3M vs $2.0M limit → BREACH
  BOOK-EQTY-03.json ← Diversified, clean — VaR $1.1M
  limits.yaml       ← Risk-Committee owned (still guarded by the hook)
  scenarios/2008-shock.json
ms-registry/        ← Local plugin marketplace stand-in for
                       http://claudecodeextensions. `risk-toolkit`
                       publishes here.
mcp/                ← Five mock MCP servers, auto-register via .mcp.json:
  pagerduty/        ←   ms-pagerduty — get_incident
  servicenow/       ←   ms-servicenow — get_record (INC-* queue)
  confluence/       ←   ms-confluence — search (RISK-RB-* runbooks)
  jira/             ←   ms-jira — create (RISK-LIMITS queue)
  slack/            ←   ms-slack — post (#risk-ops, #risk-eng-oncall)
bin/                ← Helper scripts
.claude/
  agents/risk-auditor.md   ← Opus, read-only diagnosis (D4)
  agents/risk-fixer.md     ← Sonnet, opens RISK-LIMITS JIRA (D4)
  agents/risk-verifier.md  ← Sonnet, re-runs tests + posts Slack (D4)
  skills/stress-test/      ← /stress-test skill (bundled into D1's plugin)
  settings.json            ← limits.yaml hook (bundled into D1's plugin)
CLAUDE.md           ← 101 base + 301 additions (books, registry, MCP, agents)
```

## Run

```bash
npm install
npm test          # 4/4 green
npm run dev       # GET /api/risk?book=BOOK-EQTY-01
```

Zero npm deps for the MCP servers — they auto-register via `.mcp.json`
on Claude startup.

## Demos staged here

- **D1 Plugin** — bundle `/stress-test` + the limits hook into
  `risk-toolkit/.claude-plugin/plugin.json` and publish to
  `ms-registry/`. After install, `rm -rf .claude/skills
  .claude/settings.json` and the skill + hook still fire (plugin owns
  them).
- **D2 Parallel Explore** — three subagents, one per book, each runs
  `/stress-test` in its own context. Merges into a 3-book summary;
  BOOK-EQTY-02 flagged.
- **D3 MCP** — INC-4412 triage walks pagerduty → servicenow → confluence
  → jira → slack across the five mock MCP servers.
- **D4 Agent team** — `risk-auditor` → `risk-fixer` → `risk-verifier`
  with `SendMessage` handoffs. Fixer hits the limits.yaml hook, routes
  via `ms-jira`. Verifier re-stresses and posts `ms-slack`.

## Reset between sessions

```bash
./reset-demo.sh
```

Removes any `risk-toolkit/` plugin bundle the audience created in D1,
clears `.stress-history/`, resets `data/BOOK-EQTY-*.json` to the staged
state. Skills, hooks, MCP servers, and custom agents ship with the repo
— reset doesn't remove them.
