// 1-day 99% historical Value-at-Risk.
// We use the simple historical method: sort the realized daily P&L vector
// and read off the 1st-percentile loss. No parametric assumptions, no
// Monte Carlo — the desk wanted something they could reason about by hand.

/**
 * 1-day historical VaR at the given confidence level.
 *
 * @param {number[]} pnlVector  daily P&L observations (positive = gain)
 * @param {number}   confidence e.g. 0.99 for 99%
 * @returns {number} VaR as a POSITIVE number (magnitude of the loss)
 */
export function historicalVaR(pnlVector, confidence = 0.99) {
  if (!Array.isArray(pnlVector) || pnlVector.length === 0) {
    throw new TypeError('historicalVaR: pnlVector must be a non-empty array');
  }
  const sorted = [...pnlVector].sort((a, b) => a - b);
  const tail = 1 - confidence;
  const idx = Math.max(0, Math.floor(tail * sorted.length) - 1);
  const loss = sorted[idx];
  // VaR is reported as a positive loss magnitude. Gains at the tail → 0.
  return loss < 0 ? -loss : 0;
}

/**
 * Convenience wrapper for the firm-standard 1-day 99% number.
 */
export function var99(pnlVector) {
  return historicalVaR(pnlVector, 0.99);
}

/**
 * Book-level VaR straight off the stored daily P&L history.
 */
export function bookVaR(book) {
  return var99(book.pnlHistory);
}
