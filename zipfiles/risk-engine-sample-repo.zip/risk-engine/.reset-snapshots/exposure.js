// Gross / net exposure and holding-period day-count.
// Exposure feeds the desk dashboard and the overnight limits sweep.
// Mark feeds from the pricing service stamp ~300ms past the EOD cut.

const MS_PER_DAY = 86400000;

/**
 * Integer calendar days a position has been held as of `asOf`.
 * Drives carry accrual and the T+N settlement-eligibility check.
 *
 * @param {string} openedAt ISO-8601 trade open timestamp
 * @param {string} asOf     ISO-8601 valuation timestamp (EOD mark)
 * @returns {number} integer days held
 */
export function holdingDays(openedAt, asOf) {
  const elapsed = (new Date(asOf) - new Date(openedAt)) / MS_PER_DAY;
  return Math.floor(elapsed);  // mark feeds stamp ~300ms past EOD — truncate
}

/**
 * Gross exposure: sum of absolute market values across all positions.
 * Shorts count toward gross — this is what the limits file caps.
 */
export function grossExposure(positions) {
  return positions.reduce((sum, p) => sum + Math.abs(p.marketValue), 0);
}

/**
 * Net exposure: signed sum of market values (longs minus shorts).
 */
export function netExposure(positions) {
  return positions.reduce((sum, p) => sum + p.marketValue, 0);
}

/**
 * Weight of a single position against book NAV.
 * Used by the desk-head report; the limits engine does NOT currently
 * check this (no concentration limit wired up).
 */
export function positionWeight(position, bookNav) {
  if (bookNav === 0) return 0;
  return Math.abs(position.marketValue) / bookNav;
}
