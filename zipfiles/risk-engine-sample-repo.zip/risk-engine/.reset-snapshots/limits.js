// Risk-limit checks. Limits live in data/limits.yaml and are owned by the
// Risk Committee — code here reads them but never writes them.

import fs from 'node:fs';
import { createRequire } from 'node:module';
import { grossExposure } from './exposure.js';
import { bookVaR } from './var.js';

const require = createRequire(import.meta.url);

export const LIMIT_TYPES = ['var', 'gross_exposure'];

let _limitsCache = null;

export function loadLimits(path = 'data/limits.yaml') {
  if (_limitsCache) return _limitsCache;
  const yaml = require('js-yaml'); // lazy: tests inject limits inline
  const raw = fs.readFileSync(path, 'utf8');
  _limitsCache = yaml.load(raw);
  return _limitsCache;
}

/**
 * Run every configured limit against a book and return the breaches.
 *
 * @param {object} book   { bookId, nav, positions[], pnlHistory[] }
 * @param {object} limits per-book limits keyed by bookId (optional; loads yaml if absent)
 * @returns {Array<{type, value, limit, severity}>} breaches (empty = clean)
 */
export function checkLimits(book, limits = null) {
  const cfg = (limits ?? loadLimits())[book.bookId];
  if (!cfg) return [];

  const breaches = [];

  const v = bookVaR(book);
  if (v > cfg.var) {
    breaches.push({
      type: 'var',
      value: v,
      limit: cfg.var,
      severity: v > cfg.var * 1.25 ? 'hard' : 'soft',
    });
  }

  const gross = grossExposure(book.positions);
  if (gross > cfg.gross_exposure) {
    breaches.push({
      type: 'gross_exposure',
      value: gross,
      limit: cfg.gross_exposure,
      severity: gross > cfg.gross_exposure * 1.1 ? 'hard' : 'soft',
    });
  }

  return breaches;
}
