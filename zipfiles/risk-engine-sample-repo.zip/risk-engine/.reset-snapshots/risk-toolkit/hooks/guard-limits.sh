#!/usr/bin/env bash
# PreToolUse guard: block edits to data/limits.yaml.
# Reads the hook payload JSON from stdin; exits 2 to block, 0 to allow.

payload=$(cat)

# Pull tool_input.file_path. Prefer jq if present, fall back to a grep/sed shim
# so the demo works on a fresh unzip without extra deps.
if command -v jq >/dev/null 2>&1; then
  file_path=$(printf '%s' "$payload" | jq -r '.tool_input.file_path // empty')
else
  file_path=$(printf '%s' "$payload" | grep -o '"file_path"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*"file_path"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/')
fi

case "$file_path" in
  *limits.yaml)
    echo "data/limits.yaml is Risk Committee controlled. Route changes via RISK-LIMITS JIRA with MD sign-off." >&2
    exit 2
    ;;
esac

exit 0
