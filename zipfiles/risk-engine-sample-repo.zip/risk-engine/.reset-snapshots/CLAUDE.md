# risk-engine

## What the code can't tell you
EOD marks land ~300ms after the boundary because the upstream feed isn't
instant. So elapsed time is e.g. 15.0003 days. holdingDays() must FLOOR —
ceil makes positions age a day early and trips the wrong margin tier.

## Do not touch
data/limits.yaml — Risk Committee controlled. Changes go through the
RISK-LIMITS JIRA queue with MD sign-off.

## Humans
#risk-eng-oncall · @priya.raman owns VaR methodology

## 301 additions
- Three equity books now: BOOK-EQTY-01/02/03. -02 is the hot one (VaR
  ~$2.3M vs $2.0M limit → breach). -03 is diversified and clean.
- `ms-registry/` is a local plugin marketplace (stand-in for the firm's
  http://claudecodeextensions). `risk-toolkit` publishes here — packages
  the stress-test skill + limits guard hook for other desks.
- Five mock MCP servers under `mcp/` (pagerduty, servicenow, confluence,
  jira, slack) auto-register via `.mcp.json`. Zero npm deps.
- Three custom agents in `.claude/agents/`: risk-auditor (opus, read-only
  diagnosis), risk-fixer (sonnet, confirms + opens RISK-LIMITS Jira),
  risk-verifier (sonnet, re-runs tests + posts to #risk-ops).
