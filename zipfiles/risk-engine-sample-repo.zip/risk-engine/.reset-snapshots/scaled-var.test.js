import { test } from 'node:test';
import assert from 'node:assert';
import { scaledVaR } from '../lib/var.js';

test('scaledVaR: square-root-of-time scaling — 1-day 100 → 10-day ≈ 316.23', () => {
  const tenDay = scaledVaR(100, 10);
  assert.ok(Math.abs(tenDay - 316.23) < 0.01, `expected ~316.23, got ${tenDay}`);
});

test('scaledVaR: 1-day horizon is identity', () => {
  assert.strictEqual(scaledVaR(250000, 1), 250000);
});
